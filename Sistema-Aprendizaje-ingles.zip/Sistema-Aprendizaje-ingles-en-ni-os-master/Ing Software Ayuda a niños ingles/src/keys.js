module.exports = {
    database: {
        host: 'localhost',
        user: 'root',
        password: '~~~~',
        database: 'mathebasics'
    }
};